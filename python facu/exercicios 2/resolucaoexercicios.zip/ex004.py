funcionario = {
    'nome': '',
    'setor': '',
    'periodo': ''
}
name = input('Qual o nome do funcionário? ')
area = input(f'Qual o setor do funcinário {name}: ')
horario = input(f'Em qual o pedíodo que o funcionário {name} trabalha? ')

funcionario['nome'] = name
funcionario['setor'] = area
funcionario['periodo'] = horario

print(f'O funcionario {funcionario['nome']}, trabalha no setor {funcionario['setor']}, no período {funcionario['periodo']}.')